// Nota MB = Muito Bom 
// Nota B = Bom 
// Nota R = Regular
// Nota I = Insatisfatório
// Sistema de notas: 0 a 1000

import java.util.Scanner;

public class Main {
    
    public static void main(String[] args) {
        Scanner ent = new Scanner(System.in);
        int nota1, nota2, nota3;
        int media, i, contAluno = 0;
        
        for(i = 0; i < 3; i++){
            
            contAluno++;
            System.out.println("Aluno " + contAluno + ", digite sua 1ª nota");
            nota1 = ent.nextInt();
            
            
            System.out.println("Aluno " + contAluno + ", digite sua 2ª nota");
            nota2 = ent.nextInt();
            
           
            System.out.println("Aluno " + contAluno + ", digite sua 3ª nota");
            nota3 = ent.nextInt();
            
            
            media = (nota1 + nota2 + nota3) / 3;
            System.out.println("A média do aluno " + contAluno + " é " + media);
            
            
            if( (media >= 0) && (media <500) ){
                System.out.println("Nota I");
            } else if(media < 600){
                System.out.println("Nota R");
            } else if(media < 800){
                System.out.println("Nota B");
            } else if(media <= 1000){
                System.out.println("Nota MB");
          
            }
        }       
    }
}